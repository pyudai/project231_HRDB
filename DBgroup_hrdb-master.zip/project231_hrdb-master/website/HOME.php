<!DOCTYPE html>
<html>
    <head>
        <title>HOME</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
        <style type="text/css">
        body {
            font-family: Sarabun;
            font-size: 22px;
            background-color: #F5F4F0 
        }
        .block {
            background: #CBB3A7;
            color: black;
        }
        br {
            display: block;
            content: " ";
            margin: 15px;
        }
        .threeline {
            display: block;
            content: " ";
            margin: 60px;
        }
        th {
            background-color: #CBB3A7;
        }
        
        </style>
    </head>
    <body>
        <div class="container-fluid pt-3 pb-3" style="background: #E8D8C9;">
            <a class="picture"><img src="centar.png"></a>
            <a class="text-right" style="color:#B20E10; float: right; font-size:56px; transform:translateX(-10%);">
                HOME 
            </a>
        </div>
        <br class="threeline">

        <div class="text-center">
        <br class="threeline">
        ComplexForm:<br>
            <a class="btn btn-primary" href="month.php">Monthly Pay Slip</a>
            <a class="btn btn-primary" href="TrainingResult.php">Training History</a>
            <a class="btn btn-primary" href="PerformanceReview.php">Performance Review</a>
            <a class="btn btn-primary" href="EmployeeInfo.php">Employee Infomation</a><br>
        SimpleForm:<br>
            <a class="btn btn-primary" href="course2.php">Courses</a>
             <a class="btn btn-primary" href="familymember.php">Family Member</a>
            <a class="btn btn-primary" href="Vacation.php">Vacation</a>
            <a class="btn btn-primary" href="welfare.php">Employee Welfare</a><br>
        AnalysisReport:<br>
            <a class="btn btn-primary" href="AllAbsent.php">All Absent</a>
            <a class="btn btn-primary" href="DailyTime.php">Daily Time</a>
            <a class="btn btn-primary" href="all_employee_skill.php">All Employee skill</a>
            <a class="btn btn-primary" href="department_member2.php">Department Member</a><br>
            
        </div>
          
    </body>
</html>
